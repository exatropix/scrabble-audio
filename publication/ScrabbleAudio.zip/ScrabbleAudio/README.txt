SCRABBLE AUDIO, VERSION 2.2
A keyboard Scrabble game for NVDA and JAWS, against the computer. In French, English and Spanish.

INSTALLATION
1. Unzip this file into a folder of your choice, for example Documents\ScrabbleAudio.
2. Download the dictionary for the language you want (ScrabbleAudio-dictionnaire-en, -fr or -es) and unzip it into the same folder.
   It creates the dictionnaires subfolder. You can install several languages.
3. Run ScrabbleAudio.exe.
4. If Windows shows "Windows protected your PC", choose "More info", then "Run anyway".
To switch to English: Alt, then the Langue menu: Interface, English, and Langue du jeu, English (applies from the next game, Ctrl+N).
Each language uses its official tile set: 100 tiles in English.
F1 shows the full help. Credits are in LISEZMOI.txt.
